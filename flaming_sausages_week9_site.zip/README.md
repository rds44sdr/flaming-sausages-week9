
# Flaming Sausages — Week 9 Newsletter

Hosted with GitHub Pages.

**How to use**
1) Create a public repo (e.g., `flaming-sausages-week9`)
2) Upload `index.html` and this `README.md` at the root (top level)
3) Repo → Settings → Pages → Source: *Deploy from a branch*, Branch: *main / (root)*
4) Open: https://YOUR_USERNAME.github.io/REPO_NAME
